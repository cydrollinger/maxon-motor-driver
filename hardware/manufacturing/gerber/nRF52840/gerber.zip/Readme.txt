TOP LAYER
top.GTL
topsilk.GTO
topstop.GTS
toppaste.gtp

SECOND LAYER
layer2.G2L

THIRD LAYER
layer3.G3L

BOTTOM LAYER
botsilk.GBO
botstop.GBS
bottom.GBL
botpaste.gbp

HOLES
holes.xln

BOARD OUTLINE
board_ouline.GKO 		//approximately 1.5" x 3.0" 

INSTRUCTIONS
The microstrip is based on calculations from High-Speed Digital Design pg 430

	height: .0067 in.
	width: .014 in.
	er:    3.66
        thickness: .00138

Color: mask Blue silk Yellow

Surface finish: ENEPIG
Board thickness standard ~0.063"
